## Run with Docker

To run the docker :

```bash
$ cd contrib/docker
$ docker build -t dyups .
$ docker run --name dyups -d -p :80 dyups
```

